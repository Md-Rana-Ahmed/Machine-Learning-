# Mental Health Dataset (DIU Extended Edition)

This is an extended and processed dataset for mental health assessment (**Anxiety**, **Stress**, **Depression**) among Bangladeshi university students.

- Base: Syeed et al. (2024), DOI: 10.6084/m9.figshare.25771164.v1
- Extended with DIU-collected responses (2025)
- Final combined size: ~2,038 records
- License: CC BY 4.0

## Contents
- `data/DIU_Extended_Mental_Health.csv` — **replace this placeholder** with your final combined CSV
- `data/DIU_Extended_Mental_Health_SAMPLE.csv` — 10-row sample (for quick preview)
- `data/original_source_reference.txt` — source acknowledgement
- `code/preprocess_merge.ipynb` — simple reproducible merge pipeline
- `docs/DATA_DICTIONARY.md` — variable descriptions
- `docs/CHANGES.md` — version notes
- `docs/ETHICS_STATEMENT.md` — anonymization & consent summary
