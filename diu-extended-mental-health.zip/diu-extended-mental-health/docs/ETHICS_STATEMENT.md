# ETHICS_STATEMENT

All DIU-collected responses were anonymous and voluntary. No personally identifiable information (PII) is present.
The dataset is intended for research and educational use; it must not be used for clinical diagnosis.
Base dataset reference: Syeed et al. (2024), DOI: 10.6084/m9.figshare.25771164.v1
