# DATA_DICTIONARY

| Column | Description |
|-------|-------------|
| Age | Age in years |
| Current_CGPA | Current cumulative GPA (0–4 scale) |
| Gender | Male / Female / Other |
| University | University name (can be anonymized) |
| Department | Study department/major |
| Academic_Year | 1st / 2nd / 3rd / 4th year |
| waiver_or_scholarship | Yes / No |
| GAD1–GAD7 | Anxiety items (Likert 1–4) |
| PSS1–PSS10 | Stress items (Likert 1–4) |
| DASS_D1–DASS_D7 | Depression items (Likert 1–4) |
| Anxiety Label | 0=Low/None, 1=Mild, 2=Moderate, 3=Severe |
| Stress Label | 0=Low/None, 1=Mild, 2=Moderate, 3=Severe |
| Depression Label | 0=Low/None, 1=Mild, 2=Moderate, 3=Severe |
