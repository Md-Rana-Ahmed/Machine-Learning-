# CHANGES

## v1.0.0 (2025)
- Extended Syeed et al. (2024) base dataset with DIU-collected samples (final size ≈ 2,038)
- Cleaned missing values; normalized scales to 1–4
- Unified naming (GAD1–7, PSS1–10, DASS_D1–D7)
- Prepared for ML classification (Anxiety, Stress, Depression)
